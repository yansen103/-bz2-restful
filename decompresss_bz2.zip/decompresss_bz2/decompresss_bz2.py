import os
import bz2
import json


def my_decompress_bz2(indir):
    outdir = os.sep.join(['c:','Users','ys','Desktop','h9'])
    for (dirpath, dirnames, files) in os.walk(indir):
        for filename in files:
            filepath = os.path.join(dirpath, filename)
            newfilepath = os.path.join(outdir, filename[:-4])
            with open(newfilepath, 'wb') as new_file, bz2.BZ2File(filepath, 'rb') as file:
                for data in iter(lambda: file.read(100 * 1024), b''):
                    new_file.write(data)


    return outdir



