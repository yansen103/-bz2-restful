from flask import Flask
import os
import bz2
import json
from flask import abort
from flask import redirect
from flask import request,render_template,url_for
from decompresss_bz2 import *

app =Flask(__name__)

app.route('/web/python/<indir>')
def decom_bz2(indir):
    arg = request.args.get('args')
    if arg:
        try:
            j_arg = json.loads(arg)
        except TypeError as e:
            print(e)

    if indir == 'bz2':
        outdir = my_decompress_bz2(indir)
    res =  json.dumps({"indir":j_arg,"outdir":outdir})
    return res


if __name__=="__main__":
    app.run('0.0.0.0',port=8080)
